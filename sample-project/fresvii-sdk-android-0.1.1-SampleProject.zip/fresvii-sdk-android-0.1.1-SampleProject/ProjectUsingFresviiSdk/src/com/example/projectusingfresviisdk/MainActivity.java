package com.example.projectusingfresviisdk;

import java.security.InvalidParameterException;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import com.fresvii.Fresvii;
import com.fresvii.gcm.GcmClient;
import com.fresvii.gui.FresviiActivity;
import com.fresvii.gui.FresviiActivity.FresviiViewType;
import com.fresvii.helper.ManagedLog;
import com.fresvii.helper.ManagedLog.LogLevel;
import com.fresvii.server.access.AccountAccess;
import com.fresvii.server.access.AccountAccess.UserAuthEvent;
import com.fresvii.server.access.AccountAccess.UserAuthEventListener;

public class MainActivity extends Activity implements UserAuthEventListener {
    /* This is a placeholder. Replace it with your own Fresvii APP ID!*/
    private static final String YOUR_FRESVII_APP_ID = "fdb2f3de5f404b9789acdcc8a406b802";
    
    /* This is a placeholder. Replace it with your own Fresvii APP Secret key!*/
    private static final String YOUR_FRESVII_APP_SECRET_KEY = "secret";
    
    /* This is a placeholder. Replace it with your own GCM Sender ID!*/
    /* Important note: You HAVE TO replace this with your own GCM Sender ID or VoiceChat etc. WILL NOT WORK!*/
    private static final String YOUR_GCM_SENDER_ID = "ABCDEFGHIJKLMN";
    
    /* This is a placeholder. Replace it with your own Application Name.*/
    private static final String YOUR_APP_NAME = "ProjectUsingFresviiSDK";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_main);
        
        if ( savedInstanceState == null ) {
            getFragmentManager().beginTransaction().add(R.id.container, new PlaceholderFragment()).commit();
        }
        
        // Application *may* call ManagedLog.initLog() for debugging purposes.
        ManagedLog.initLog(YOUR_APP_NAME, LogLevel.VERBOSE);
        
        // You have to start the FresviiSDk before you interact with it.
        Fresvii.start(super.getApplicationContext(), YOUR_FRESVII_APP_ID, YOUR_FRESVII_APP_SECRET_KEY, YOUR_APP_NAME);
        
        // Add a UserAuthEventListener
        AccountAccess.addUserAuthEventListener(this);
    }
    
    @Override
    protected void onDestroy() {
        // Remove the UserAuthEventListener
        AccountAccess.removeUserAuthEventListener(this);
        
        super.onDestroy();
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if ( id == R.id.action_settings ) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    public void onUserAuthEvent(String userId, UserAuthEvent event) {
        if ( event == UserAuthEvent.USER_LOGGED_IN ) {
            try {
                // Application *may* initialize GCM client if it wants to receive GCM notifications from Fresvii server
                // We have to be *logged in* to do this
                GcmClient.getInstance().registerAndAddDeviceToken(YOUR_GCM_SENDER_ID);
            } catch ( InvalidParameterException e ) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        
        public PlaceholderFragment() {
        }
        
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            
            rootView.findViewById(R.id.fresviiForumButton).setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Display the Fresvii Forum
                    FresviiActivity.start(getActivity(), FresviiViewType.FORUM);
                }
            });
            
            rootView.findViewById(R.id.fresviiProfileButton).setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Display the Fresvii Profile
                    FresviiActivity.start(getActivity(), FresviiViewType.PROFILE);
                }
            });
            
            return rootView;
        }
    }
}
